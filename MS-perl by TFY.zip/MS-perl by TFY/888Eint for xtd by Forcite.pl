#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

###### Begin User INPUT ####################

my $doc = Documents->Import("library://20251111/6_NBRandPalmitic acid/parallel5ns/NPTandNVT-compass  Script/4NVT300K_5000ps.xtd");

my $forcite = Modules->Forcite;
$forcite->ChangeSettings(Settings(CurrentForcefield => "COMPASSIII",   #	Dreiding, COMPASS, COMPASSII,COMPASSIII, cvff, pcff, Universal, etc, for imported FF use: /<folder>/<forcefield>
					    Quality => "Medium",      # Coarse, Medium, Fine, or Ultra-fine
                              AssignForcefieldTypes => 'No', 
	                           ChargeAssignment => 'Use current'));


#change your component##############################################################20251121 11:00 
my $A_component = "A";
my $B_component = "B";
my $AB_component = "A-B";
my $unit1 = "kcal/mol";
######################################################################################20251121 11:00

####### End User INPUT #####################

my $std = Documents->New("Eint results.std");
my $dataSheet = $std->ActiveSheet;

$dataSheet->ColumnHeading(0) = "Frame number";	
$dataSheet->ColumnHeading(1) = "Model $AB_component";
$dataSheet->ColumnHeading(2) = "E $AB_component ($unit1)";
$dataSheet->ColumnHeading(3) = "Model $A_component";
$dataSheet->ColumnHeading(4) = "E $A_component ($unit1)";
$dataSheet->ColumnHeading(5) = "Model $B_component";
$dataSheet->ColumnHeading(6) = "E $B_component ($unit1)";
$dataSheet->ColumnHeading(7) = "Eint ($unit1)";

### Now loop the xtd to read the energy for each frame ######

my $trajectory = $doc->Trajectory;
my $XtdFrames = $trajectory->NumFrames;

 for (my $i = 26; $i <= $XtdFrames ; $i = $i + 2) 
 {
	$doc->Trajectory->CurrentFrame = $i;
	my $ABDoc = Documents->New("$AB_component.xsd");
	my $ADoc = Documents->New("$A_component.xsd");
	my $BDoc = Documents->New("$B_component");

	$ABDoc->CopyFrom($doc);

	$ADoc->CopyFrom($doc);
	$ADoc->UnitCell->Sets("$B_component")->Atoms->Delete;

	$BDoc->CopyFrom($doc);
	$BDoc->UnitCell->Sets("$A_component")->Atoms->Delete;

	$dataSheet->Cell($i-1,0) = $i;
	$dataSheet->Cell($i-1,1) = $ABDoc;
	$dataSheet->Cell($i-1,3) = $ADoc;
	$dataSheet->Cell($i-1,5) = $BDoc;

############### Get EAB #########################
	$forcite->Energy->Run($ABDoc);
	$dataSheet->Cell($i-1,2) = $ABDoc->PotentialEnergy;

############### Get EA #########################
	$forcite->Energy->Run($ADoc);
	$dataSheet->Cell($i-1,4) = $ADoc->PotentialEnergy;

############### Get EB #########################
	$forcite->Energy->Run($BDoc);
	$dataSheet->Cell($i-1,6) = $BDoc->PotentialEnergy;

############### Get Eint #########################
	my $EAB=$dataSheet->Cell($i-1,2);      #kcal/mol
	my $EA =$dataSheet->Cell($i-1,4);      #kcal/mol
	my $EB =$dataSheet->Cell($i-1,6);      #kcal/mol
	my $Eint = $EAB - ($EA + $EB);         #kcal/mol

	$dataSheet->Cell($i-1,7)         =$Eint;

	$ABDoc->Discard;
	$ADoc->Discard;
	$BDoc->Discard;
}
