#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);
Tools->PolymerBuilder->ChangeSettings(Settings(
	Orientation => 'Random', 
	FlipProbability => 0.5, 
	UseRandomTorsion => 'Yes'));
my $repeatUnit = $Documents{"ACM_Units_EA.xsd"};

#Enter the number of chains in the $chain_number
for(my $chain_number = 20; $chain_number != 0; $chain_number = $chain_number-1)
{
#Enter the name of the folder at $doc
my $doc = Documents-> New ("$chain_number.xsd");
my $polymer = Tools->PolymerBuilder->Homopolymer->Build($doc, $repeatUnit, 10);

#Geometry Optimization
my $results = Modules->Forcite->GeometryOptimization->Run($doc, Settings(
        #Quality => 'Fine', 
	NonPeriodicvdWAtomCubicSplineCutOff => 15.5, 
	NonPeriodicvdWChargeGroupCubicSplineCutOff => 15.5, 
	NonPeriodicEAMAtomCubicSplineCutOff => 15.5, 
	CurrentForcefield => 'Dreiding', 
	ChargeAssignment => 'Charge using QEq', 
	AssignForcefieldTypes => 'Yes',
	OptimizationAlgorithm => 'Smart',   
	MaxIterations => 100000, 
	MaxForce => 0.005, 
	MaxStress => 0.005, 
	MaxDisplacement => 2e-005, 
	MaxEnergy => 1e-005, 
	UseMaxStress => 'Yes', 
	UseMaxDisplacement => 'Yes', 
	ExternalPressure => 0.000101,
	MaxChargeIterations => 500, 
	ConvergenceLimit => 5e-005, 
	InitialCharge => 'Current'));

};

#my $results = Modules->Forcite->GeometryOptimization->Run($doc, Settings(
	#'3DPeriodicvdWEwaldSumAccuracy' => 0.0001, 
	#'3DPeriodicElectrostaticEwaldSumAccuracy' => 0.0001, 
	#'3DPeriodicElectrostaticPPPMAccuracy' => 0.0001, 
	#'3DPeriodicvdWAtomCubicSplineCutOff' => 15.5, 
	#'3DPeriodicvdWChargeGroupCubicSplineCutOff' => 15.5, 
	#'3DPeriodicEAMAtomCubicSplineCutOff' => 15.5, 
	#CurrentForcefield => 'Dreiding', 
	#AssignForcefieldTypes => 'Yes', 
	#ChargeAssignment => 'Use current', 
	#MaxIterations => 100000, 
	#MaxForce => 0.005, 
	#MaxStress => 0.005, 
	#MaxDisplacement => 2e-005, 
	#MaxEnergy => 1e-005, 
	#UseMaxStress => 'Yes', 
	#UseMaxDisplacement => 'Yes', 
	#ExternalPressure => 0.000101));

