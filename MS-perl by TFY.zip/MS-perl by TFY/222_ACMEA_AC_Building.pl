#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

my $acConstruction = Modules->AmorphousCell->Construction;

for (my $n = 1; $n<21 ; $n++) {

my $doc2 = Documents->Import("library://20250416_ACMXX+NBR_Dreiding/POLYMER/ACM_EA/create_ACM_EA  Script/$n.xsd");
$acConstruction->AddComponent($doc2);
$acConstruction->Loading($doc2) = 2;

}

my $results = $acConstruction->Run(Settings(
	Temperature => 300, 
	Quality => 'Medium',
	OptimizeGeometry => 'Yes', 
	Configurations => 1, 
	TargetDensity => 1.2, 
	LoadingMoves => 200, 
	CheckCloseContacts => 'Yes', 
	CloseContactvdWScale => 0.25, 
	NumberBiasedTorsionSteps => 100, 
	NumberBiasedHeadSegmentSteps => 100, 
	LookAhead => 2, 
	'3DPeriodicElectrostaticSummationMethod' => 'Atom based', 
	CurrentForcefield => 'Dreiding',
	AssignForcefieldTypes => 'Yes',
	ChargeAssignment => 'Use current'));
my $outTrajectory = $results->Trajectory;
my $outTrajectoryName = $outTrajectory->Name = "01_Trajectory";

