#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

Tools->PolymerBuilder->ChangeSettings(Settings(
	ForceConcentrations => 'Yes', 
	UseProbabilities => 'No'));
my $randomCopolymer = Tools->PolymerBuilder->RandomCopolymer;
my $repeatUnit0 = $Documents{"ACM_Units_EA.xsd"};
my $repeatUnit1 = $Documents{"ACM_Units_BA.xsd"};

$randomCopolymer->ClearRepeatUnits();
$randomCopolymer->AddRepeatUnit($repeatUnit0,0,0.5);
$randomCopolymer->AddRepeatUnit($repeatUnit1,0,0.5);

#set concentration
$randomCopolymer->SetConcentration(0, 0.5);
$randomCopolymer->SetConcentration(1, 0.5);

#
$randomCopolymer->SetReactivityRatio(0, 0, 1);
$randomCopolymer->SetReactivityRatio(0, 1, 0.5);
$randomCopolymer->SetReactivityRatio(1, 0, 0.5);
$randomCopolymer->SetReactivityRatio(1, 1, 1);

#Enter the number of chains in the $chain_number
for(my $chain_number = 20; $chain_number != 0; $chain_number = $chain_number-1)
{

#Enter the name of the folder at $doc
my $doc = Documents-> New ("$chain_number.xsd");
my $polymer = $randomCopolymer->Build($doc,10, , ,);

#Geometry Optimization
my $results = Modules->Forcite->GeometryOptimization->Run($doc, Settings(
        #Quality => 'Fine', 
	NonPeriodicvdWAtomCubicSplineCutOff => 15.5, 
	NonPeriodicvdWChargeGroupCubicSplineCutOff => 15.5, 
	NonPeriodicEAMAtomCubicSplineCutOff => 15.5, 
	CurrentForcefield => 'Dreiding', 
	ChargeAssignment => 'Charge using QEq', 
	AssignForcefieldTypes => 'Yes',
	OptimizationAlgorithm => 'Smart',   
	MaxIterations => 100000, 
	MaxForce => 0.005, 
	MaxStress => 0.005, 
	MaxDisplacement => 2e-005, 
	MaxEnergy => 1e-005, 
	UseMaxStress => 'Yes', 
	UseMaxDisplacement => 'Yes', 
	ExternalPressure => 0.000101,
	MaxChargeIterations => 500, 
	ConvergenceLimit => 5e-005, 
	InitialCharge => 'Current'));

};