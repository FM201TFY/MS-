#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

###### Begin User INPUT ####################

my $doc = $Documents{"4NVT300K_5000ps.xtd"};

  

my $forcite = Modules->Forcite;
$forcite->ChangeSettings(Settings(
	CurrentForcefield => 'Dreiding', #	Dreiding, COMPASS, COMPASSII,COMPASSIII, cvff, pcff, Universal, etc, for imported FF use: /<folder>/<forcefield>
	AssignForcefieldTypes => 'Yes', 
	Quality => "Medium",# Coarse, Medium, Fine, or Ultra-fine
	ChargeAssignment => 'Use current', 
	IncludeStructuresInStudyTable => 'Yes',     
	ActiveDocumentFrameRange => '15-51'));


####### End User INPUT #####################

my $std = Documents->New("0_CED results.std");
my $dataSheet = $std->ActiveSheet;

#change your component
my $A_component = "NBR";
my $B_component = "ACMEA";
my $AB_component = "ACMEA-NBR";
my $unit1 = "J/m^3";
my $unit2 = "(J/cm^3)^0.5";

$dataSheet->ColumnHeading(0) = "Frame number";	
$dataSheet->ColumnHeading(1) = "Model $AB_component";
$dataSheet->ColumnHeading(2) = "CED $AB_component ($unit1)";
$dataSheet->ColumnHeading(3) = "Solubility parameter $AB_component ($unit2)";
$dataSheet->ColumnHeading(4) = "Model $A_component";
$dataSheet->ColumnHeading(5) = "CED $A_component ($unit1)";
$dataSheet->ColumnHeading(6) = "Solubility parameter $A_component ($unit2)";
$dataSheet->ColumnHeading(7) = "Model $B_component";
$dataSheet->ColumnHeading(8) = "CED $B_component ($unit1)";
$dataSheet->ColumnHeading(9) = "Solubility parameter $B_component ($unit2)";
$dataSheet->ColumnHeading(10) = "Eint ($unit1)";

### Now loop the xtd to read the energy for each frame ######

my $trajectory = $doc->Trajectory;
my $XtdFrames = $trajectory->NumFrames;

 for (my $i = 15; $i <= $XtdFrames ; $i = $i + 1) 
 {
	$doc->Trajectory->CurrentFrame = $i;
	my $ABDoc = Documents->New("$AB_component.xsd");
	my $ADoc = Documents->New("$A_component.xsd");
	my $BDoc = Documents->New("$B_component.xsd");	
	

	$ABDoc->CopyFrom($doc);

	$ADoc->CopyFrom($doc);
	$ADoc->UnitCell->Sets("$B_component")->Atoms->Delete;

	$BDoc->CopyFrom($doc);
	$BDoc->UnitCell->Sets("$A_component")->Atoms->Delete;

	$dataSheet->Cell($i-1,0) = $i;
	$dataSheet->Cell($i-1,1) = $ABDoc;
	$dataSheet->Cell($i-1,4) = $ADoc;
	$dataSheet->Cell($i-1,7) = $BDoc;

############### Get EAB #########################
	$forcite->CohesiveEnergyDensity->Run($ABDoc);
	my $ABstd = $Documents{"$AB_component.std"};
	$dataSheet->Cell($i-1,2) = $ABstd->Cell(0,1);
	$dataSheet->Cell($i-1,3) = $ABstd->Cell(0,2);

############### Get EA #########################
	$forcite->CohesiveEnergyDensity->Run($ADoc);
	my $Astd = $Documents{"$A_component.std"};
	$dataSheet->Cell($i-1,5) = $Astd->Cell(0,1);
	$dataSheet->Cell($i-1,6) = $Astd->Cell(0,2);

############### Get EB #########################
	$forcite->CohesiveEnergyDensity->Run($BDoc);
	my $Bstd = $Documents{"$B_component.std"};
	$dataSheet->Cell($i-1,8) = $Bstd->Cell(0,1);
	$dataSheet->Cell($i-1,9) = $Bstd->Cell(0,2);


	$ABDoc->Discard;
	$ADoc->Discard;
	$BDoc->Discard;
	$ABstd->Delete;
	$Astd->Delete;
	$Bstd->Delete;
}
