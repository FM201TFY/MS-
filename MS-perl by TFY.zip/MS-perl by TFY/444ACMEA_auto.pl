#!perl

######The code still needs to be improved. The file names need to be modified at lines 102 and 164#####
use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

##GO -> NPT500K5ns -> NPT300K2ns -> NVT300K1ns ->NVT300K5ns##

##################################################################
########################input GO parameter########################
##################################################################

my $inputstructure = $Documents{"11111.xsd"};
my $doc1 = $inputstructure;

##################################################################
########################Run GeometryOptimization##################
##################################################################

my $results1 = Modules->Forcite->GeometryOptimization->Run($doc1, Settings(
        #Quality => 'Fine', 
	NonPeriodicvdWAtomCubicSplineCutOff => 15.5, 
	NonPeriodicvdWChargeGroupCubicSplineCutOff => 15.5, 
	NonPeriodicEAMAtomCubicSplineCutOff => 15.5, 
	CurrentForcefield => 'Dreiding', 
	ChargeAssignment => 'Use current', 
	AssignForcefieldTypes => 'Yes',
	OptimizationAlgorithm => 'Smart',   
	MaxIterations => 100000,  #the number of steps of iteration
	MaxForce => 0.005, 
	MaxStress => 0.005, 
	MaxDisplacement => 2e-005, 
	MaxEnergy => 1e-005, 
	UseMaxStress => 'Yes', 
	UseMaxDisplacement => 'Yes', 
	ExternalPressure => 0.000101));
	
# name is able to modify	
$doc1->Name = "2NPT500K";
my $xsd_file = $Documents{"2NPT500K.xsd"};

##################################################################
########################input NPT500K parameters###################
##################################################################

my $NPT_500K_temperature = 500;
my $NPT_500K_trajectoryFrequency = 100000;
my $NPT_500K_numberOfSteps = 5000000;
my $NPT_500K_time = $NPT_500K_numberOfSteps/1000; #units:ps

#select Traj
my $NPT_500K_initial_frame = 1;
my $NPT_500K_totalnumberofFrame = ($NPT_500K_numberOfSteps/$NPT_500K_trajectoryFrequency) + 1;
my $NPT_500K_Thetimeintervaloftheoutputconformation = $NPT_500K_trajectoryFrequency/1000; #units is ps
my $NPT_500K_numberofconformation = 1; #hope the number of output conformations
my $NPT_500K_selfaddnum = $NPT_500K_totalnumberofFrame/$NPT_500K_numberofconformation;


for (my $NPT_500K_current_frame = $NPT_500K_initial_frame; $NPT_500K_current_frame <= $NPT_500K_totalnumberofFrame; $NPT_500K_current_frame = $NPT_500K_current_frame + $NPT_500K_selfaddnum)
    {
        if ($NPT_500K_current_frame = $NPT_500K_totalnumberofFrame)
        {
        
##################################################################
########################run NPT500K ###################
##################################################################

		my $doc2 = $xsd_file; #yu 40 hang dai ma xiang dui ying.
		my $results2 = Modules->Forcite->Dynamics->Run($doc2, Settings(
			Quality => 'Medium', 
			CurrentForcefield => 'Dreiding', 
			ChargeAssignment => 'Use current',
			AssignForcefieldTypes => 'Yes', 
			Ensemble3D => 'NPT', 
			Temperature => $NPT_500K_temperature, 
			Pressure => 0.000101, 
			NumberOfSteps => $NPT_500K_numberOfSteps, 
			TimeStep => 1, 
			TrajectoryFrequency => $NPT_500K_trajectoryFrequency, 
			Thermostat => 'Nose', 
			QRatio => 0.01, 
			Barostat => 'Berendsen', 
			PressureDecayConstant => 0.1, 
			EnergyDeviation => 5000, 
			InitialVelocities => 'Random', 
			StressXX => -0.000101, 
			StressYY => -0.000101, 
			StressZZ => -0.000101, 
			SouzaMartinsBarostatCellTimeConstant => 100));
		my $NPT_500K_outTrajectory = $results2->Trajectory;
		
		my $NPT_500K_outTrajectoryname = $NPT_500K_outTrajectory->Name = "2NPT$NPT_500K_temperature"."K_$NPT_500K_time"."ps";
		my $NPT_500K_traj = $Documents{"2NPT$NPT_500K_temperature"."K_$NPT_500K_time"."ps.xtd"};
		$NPT_500K_traj->CurrentFrame = $NPT_500K_current_frame;
		my $nextprocessfile = $NPT_500K_traj;
		my $afterNPT500K_xsd_file = $nextprocessfile->SaveAs("3NPT300K.xsd");

	}

}
my $afterNPT500K_xsd_file = $Documents{"3NPT300K.xsd"};#97 code

##################################################################
########################input NPT300K parameters###################
##################################################################
my $NPT_300K_temperature = 300;
my $NPT_300K_trajectoryFrequency = 100000;
my $NPT_300K_numberOfSteps = 2000000;
my $NPT_300K_time = $NPT_300K_numberOfSteps/1000;

#select Traj
my $NPT_300K_initial_frame = 1;
my $NPT_300K_totalnumberofFrame = ($NPT_300K_numberOfSteps/$NPT_300K_trajectoryFrequency) + 1;
my $NPT_300K_Thetimeintervaloftheoutputconformation = $NPT_300K_trajectoryFrequency/1000; #units is ps
my $NPT_300K_numberofconformation = 1; #hope the number of output conformations
my $NPT_300K_selfaddnum = $NPT_300K_totalnumberofFrame/$NPT_300K_numberofconformation;


for (my $NPT_300K_current_frame = $NPT_300K_initial_frame; $NPT_300K_current_frame <= $NPT_300K_totalnumberofFrame; $NPT_300K_current_frame = $NPT_300K_current_frame + $NPT_300K_selfaddnum)
    {
    #zhi qu zui hou yi zhen 
        if ($NPT_300K_current_frame = $NPT_300K_totalnumberofFrame)
        {
        
##################################################################
########################run NPT300K ###################
##################################################################

		my $doc3 = $afterNPT500K_xsd_file; #102 code
		#my $doc3 = $Documents{"3NPT$NPT_500K_temperature"."_Frame_$NPT_500K_current_frame"."$NPT_500K_xsdfiletime"."ps.xsd"};
		my $NPT_300K_results = Modules->Forcite->Dynamics->Run($doc3, Settings(
			Quality => 'Medium', 
			CurrentForcefield => 'Dreiding', 
			ChargeAssignment => 'Use current',
			AssignForcefieldTypes => 'Yes', 
			Ensemble3D => 'NPT', 
			Temperature => $NPT_300K_temperature, 
			Pressure => 0.000101, 
			NumberOfSteps => $NPT_300K_numberOfSteps, 
			TimeStep => 1, 
			TrajectoryFrequency => $NPT_300K_trajectoryFrequency, 
			Thermostat => 'Nose', 
			QRatio => 0.01, 
			Barostat => 'Berendsen', 
			PressureDecayConstant => 0.1, 
			EnergyDeviation => 5000, 
			InitialVelocities => 'Random', 
			StressXX => -0.000101, 
			StressYY => -0.000101, 
			StressZZ => -0.000101, 
			SouzaMartinsBarostatCellTimeConstant => 100));
		my $NPT_300K_outTrajectory = $NPT_300K_results->Trajectory;
		my $NPT_300K_outTrajectoryname = $NPT_300K_outTrajectory->Name = "3NPT$NPT_300K_temperature"."K_$NPT_300K_time"."ps";
        
		my $NPT_300K_traj = $Documents{"3NPT$NPT_300K_temperature"."K_$NPT_300K_time"."ps.xtd"};
		$NPT_300K_traj->CurrentFrame = $NPT_300K_current_frame;
		my $mol = $NPT_300K_traj;
		my $afterNPT300Kxsd_file = $mol->SaveAs("4NVT300K.xsd");
	}

}

my $afterNPT300Kxsd_file = $Documents{"4NVT300K.xsd"};#159 code

##################################################################
########################input NVT300K parameters###################
##################################################################
my $NVT300K_temperature = 300;
my $NVT300K_trajectoryFrequency = 100000;
my $NVT300K_numberOfSteps = 1000000;
my $NVT300K_time = $NVT300K_numberOfSteps/1000;#units is ps

#select Traj
my $NVT300K_initial_frame = 1;
my $NVT300K_totalnumberofFrame = ($NVT300K_numberOfSteps/$NVT300K_trajectoryFrequency) + 1;
my $NVT300K_Thetimeintervaloftheoutputconformation = $NVT300K_trajectoryFrequency/1000; #units is ps
my $NVT300K_numberofconformation = 1; #hope the number of output conformations
my $NVT300K_selfaddnum = $NVT300K_totalnumberofFrame/$NVT300K_numberofconformation;


for (my $NVT300K_current_frame = $NVT300K_initial_frame; $NVT300K_current_frame <= $NVT300K_totalnumberofFrame; $NVT300K_current_frame = $NVT300K_current_frame + $NVT300K_selfaddnum)
    {
    
##################################################################
########################run NVT300K ###################
##################################################################

        if ($NVT300K_current_frame = $NVT300K_totalnumberofFrame)
        {
		my $doc4 = $afterNPT300Kxsd_file; #164 code  

		my $NVT300K_results = Modules->Forcite->Dynamics->Run($doc4, Settings(
			Quality => 'Fine', 
			CurrentForcefield => 'Dreiding', 
			AssignForcefieldTypes => 'No', 
			ChargeAssignment => 'Use current', 
			Ensemble3D => 'NVT', 
			Temperature => $NVT300K_temperature, 
			Pressure => 0.000101, 
			NumberOfSteps => $NVT300K_numberOfSteps, 
			TimeStep => 1, 
			TrajectoryFrequency => $NVT300K_trajectoryFrequency, 
			QRatio => 0.001, 
			PressureDecayConstant => 0.11, 
			EnergyDeviation => 5000, 
			InitialVelocities => 'Current', 
			StressXX => -0.000101, 
			StressYY => -0.000101, 
			StressZZ => -0.000101, 
			SouzaMartinsBarostatCellTimeConstant => 100));
			
		my $NVT300K_outTrajectory = $NVT300K_results->Trajectory;
		my $NVT300K_outTrajectoryname = $NVT300K_outTrajectory->Name = "4NVT$NVT300K_temperature"."K_$NVT300K_time"."ps";
        
		my $NVT300K_traj = $Documents{"4NVT$NVT300K_temperature"."K_$NVT300K_time"."ps.xtd"};
		$NVT300K_traj->CurrentFrame = $NVT300K_current_frame;
		my $mol = $NVT300K_traj;
		my $nextprocessxsd_file = $mol->SaveAs("5NVT300K_relaxation1ns.xsd");
	}
    }


