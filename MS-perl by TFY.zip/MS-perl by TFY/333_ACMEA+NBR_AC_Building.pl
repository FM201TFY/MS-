#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

my $acConstruction = Modules->AmorphousCell->Construction;

for (my $n = 1; $n<21 ; $n++) {
my $doc1 =  Documents->Import("library://20250416_ACMXX+NBR_Dreiding/POLYMER/NBR_33AN+67Butadiene(80TB)/create_NBR  Script/$n.xsd");
$acConstruction->AddComponent($doc1);
$acConstruction->Loading($doc1) = 1;


my $doc2 = Documents->Import("library://20250416_ACMXX+NBR_Dreiding/POLYMER/ACM_EA/create_ACM_EA  Script/$n.xsd");
$acConstruction->AddComponent($doc2);
$acConstruction->Loading($doc2) = 1;

}

my $results = $acConstruction->Run(Settings(
	Temperature => 300, 
	Quality => 'Medium',
	OptimizeGeometry => 'Yes', 
	Configurations => 1, 
	TargetDensity => 1.2, 
	LoadingMoves => 200, 
	CheckCloseContacts => 'Yes', 
	CloseContactvdWScale => 0.25, 
	NumberBiasedTorsionSteps => 100, 
	NumberBiasedHeadSegmentSteps => 100, 
	LookAhead => 2, 
	'3DPeriodicElectrostaticSummationMethod' => 'Atom based', 
	CurrentForcefield => 'Dreiding',
	AssignForcefieldTypes => 'Yes',
	ChargeAssignment => 'Use current'));
my $outTrajectory = $results->Trajectory;
my $outTrajectoryName = $outTrajectory->Name = "01_Trajectory";

