#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

###############################################################
##################### Select Traj #####################
###############################################################

#my $traj_name = "z3_NVT300K_5ns.xtd";
my $initial_frame = 460;  #It is 1 more than the normal frame rate.  Corresponding to 18 lines of code
my $total_frame = 610;  #The overall output conformation
my $Thetimeintervaloftheoutputconformation = 10;  #interval time.   units:ps
my $Thenumberofoutputconformations = 3;  #need the number of output conformations
my $selfaddnum = ($total_frame-$initial_frame)/3;  #need the frame of models 
my $traj = Documents->Import("library://20251106/2_PEEKK/parallel8ns/7_NVTagain6ns Forcite Dynamics/7_NVTagain6ns.xtd");

#create .std
my $std = Documents->New("Free Volume.std");
my $dataSheet = $std->ActiveSheet;
	
$dataSheet->ColumnHeading(0) = "Conformation";
$dataSheet->ColumnHeading(1) = "Free Volume";


for (my $current_frame = $initial_frame; $current_frame < $total_frame; $current_frame = $current_frame + $selfaddnum,$Thenumberofoutputconformations = $Thenumberofoutputconformations-1)
	{
		#25 Corresponding to 12 lines of code
		$traj->CurrentFrame = ($current_frame+1);
		my $mol = $traj;
		#$mol->SaveAs("Frame_$current_frame.xsd");
		my $mol1 = Documents->New("Frame_$current_frame.xsd");
		$mol1 ->CopyFrom($mol);

		my $current_time = $current_frame*$Thetimeintervaloftheoutputconformation;       
		print ("This is the conformation at the $current_time ps.\n");
		
		

###############################################################
##################### Calculate FV #####################
###############################################################

		my $doc = $Documents{"Frame_$current_frame.xsd"};
		my $fieldConnolly = Tools->AtomVolumesSurfaces->Connolly->Calculate($doc, Settings(
			GridInterval => 0.25, 
			ConnollyRadius => 0.1));
		$fieldConnolly->Style = "None";
		my $isosurfaceConnolly = $fieldConnolly->CreateIsosurface([
			IsoValue => 0.0, 
			HasFlippedNormals  => "No"]);
	
		my $TotalVolume = $doc->DisplayRange->AtomVolumesFields("Atom Volumes Field")->FieldVolume;
		my $EnclosedVolume = $doc->DisplayRange->Isosurfaces("Connolly Surface")->EnclosedVolume;
		my $freeVolume = $TotalVolume -	$EnclosedVolume;

		print "Frame_$current_frame.xsd:\n System ocuppiedVolume and FreeVolume:\n";
		print "occupied Volume is:$EnclosedVolume\n";
		print "Free Volume is: $freeVolume\n";
		print "\n";
		$dataSheet->Cell($Thenumberofoutputconformations,0) = $mol1;
		$dataSheet->Cell($Thenumberofoutputconformations,1) = $freeVolume;	
	
};





