#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

#define input datas
my $inputStructure = $Documents{"400K.xsd"};
my $initial_temperature = 400;
my $ending_temperature = 200;
my $point = 8;
my $per_point_temperature = ($initial_temperature-$ending_temperature)/$point;
my $numberOfSteps_1 = 30000;
my $trajectoryFrequency_1 = 1000;
my $thenumberofconformation = $numberOfSteps_1/$trajectoryFrequency_1;


my $doc1 = $inputStructure;
my $results = Modules->Forcite->Dynamics->Run($doc1, Settings(
	Quality => 'Fine', 
	CurrentForcefield => 'Dreiding', 
	AssignForcefieldTypes => 'Yes', 
	Ensemble3D => 'NPT', 
	Temperature => $initial_temperature, 
	Pressure => 0.000101, #GPa
	NumberOfSteps => $numberOfSteps_1, 
	TimeStep => 1, 
	TrajectoryFrequency => $trajectoryFrequency_1, 
	EnergyDeviation => 50000,  #kcal/mol
	InitialVelocities => 'Current', 
	StressXX => -0.000101, 
	StressYY => -0.000101, 
	StressZZ => -0.000101, 
	SouzaMartinsBarostatCellTimeConstant => 100));	
my $outTrajectory = $results->Trajectory;
my $outTrajectoryname = $outTrajectory->Name = "$initial_temperature K";

#define input datas to select Traj
my $initial_frame = 1;  #
my $numberOfSteps_2 = 30000;
my $trajectoryFrequency_2 = 1000;
my $thenumberofconformation_2 = $numberOfSteps_2/$trajectoryFrequency_2;
my $total_frame = $thenumberofconformation_2+1;
my $Thetimeintervaloftheoutputconformation = $trajectoryFrequency_2/1000; #ps
my $Thenumberofoutputconformations = 1; #hope the number of output conformations
my $selfaddnum = ($total_frame-$initial_frame+1)/$Thenumberofoutputconformations;


#########################################################################################################
################################### Temperature ratio of decreasing ###################################
#########################################################################################################
my $relaxation_temperature = $initial_temperature-$per_point_temperature;
for (my $current_temperature = $relaxation_temperature; $current_temperature >= $ending_temperature; $current_temperature = $current_temperature-$per_point_temperature)
{
    my $read_currentTemperature = $current_temperature + $per_point_temperature;
    my $traj_name = "$read_currentTemperature K.xtd";

#select Traj

    for (my $current_frame = $initial_frame; $current_frame <= $total_frame; $current_frame = $current_frame + $selfaddnum)
    {
        print ("this is in totalFrame:$total_frame \n");
        print ("this is in current_frame:$current_frame \n");
        
        if ($current_frame = $total_frame)

        {
            print ("this is in if totalFrame:$total_frame \n");
            print ("this is in if current_frame:$current_frame \n");
            my $traj = $Documents{$traj_name};
            $traj->CurrentFrame = $current_frame;
            my $mol = $traj;
            my $xsd_file = $mol->SaveAs("$current_temperature"."_Frame_$current_frame".".xsd");
            my $current_time = $current_frame*$Thetimeintervaloftheoutputconformation;       
            print ("This is the conformation at the $current_time ps.\n");
            print ("\n");
            
            my $doc2 = $xsd_file;
            my $results = Modules->Forcite->Dynamics->Run($doc2, Settings(
	        Quality => 'Fine', 
	        CurrentForcefield => 'Dreiding', 
	        AssignForcefieldTypes => 'Yes', 
	        Ensemble3D => 'NPT', 
	        Temperature => $current_temperature, 
	        Pressure => 0.000101, #GPa
	        NumberOfSteps => $numberOfSteps_2, 
        	TimeStep => 1, 
        	TrajectoryFrequency => $trajectoryFrequency_2, 
        	EnergyDeviation => 50000,  #kcal/mol
        	InitialVelocities => 'Random', 
        	StressXX => -0.000101, 
        	StressYY => -0.000101, 
        	StressZZ => -0.000101, 
        	SouzaMartinsBarostatCellTimeConstant => 100));	
            my $outTrajectory = $results->Trajectory;
            my $outTrajectoryname = $outTrajectory->Name = "$current_temperature K";
            
        }

    };


};




