#!perl

use strict;
use Getopt::Long;
use MaterialsScript qw(:all);

#select Traj
my $traj_name = "z3_NVT300K_5ns_2.xtd";
my $initial_frame = 46;  #
my $total_frame = 51;
my $Thetimeintervaloftheoutputconformation = 100; #ps
my $Thenumberofoutputconformations = 3;
my $selfaddnum = ($total_frame-$initial_frame+1)/3;

for (my $current_frame = $initial_frame; $current_frame < $total_frame; $current_frame = $current_frame + $selfaddnum)
{
my $traj = $Documents{$traj_name};
$traj->CurrentFrame = $current_frame;
my $mol = $traj;
$mol->SaveAs("Frame_$current_frame.xsd");
my $current_time = $current_frame*$Thetimeintervaloftheoutputconformation;       
print ("This is the conformation at the $current_time ps.\n");

# calculate FV
my $doc = $Documents{"Frame_$current_frame.xsd"};
my $fieldConnolly = Tools->AtomVolumesSurfaces->Connolly->Calculate($doc, Settings(
	GridInterval => 0.25, 
	ConnollyRadius => 0.1));
$fieldConnolly->Style = "None";
my $isosurfaceConnolly = $fieldConnolly->CreateIsosurface([
	IsoValue => 0.0, 
	HasFlippedNormals  => "No"]);
	
my $TotalVolume = $doc->DisplayRange->AtomVolumesFields("Atom Volumes Field")->FieldVolume;
my $EnclosedVolume = $doc->DisplayRange->Isosurfaces("Connolly Surface")->EnclosedVolume;
my $freeVolume = $TotalVolume -	$EnclosedVolume;
#if ($doc_num == 1){};
print "\n";
print "Frame_$current_frame.xsd:____System ocuppiedVolume and FreeVolume:\n";
print "occupied Volume is:$EnclosedVolume\n";
print "Free Volume is: $freeVolume\n";

};


